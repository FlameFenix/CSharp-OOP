﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BordedControl
{
    public interface IBirthdate
    {
        public string Birthdate { get; }
    }
}
