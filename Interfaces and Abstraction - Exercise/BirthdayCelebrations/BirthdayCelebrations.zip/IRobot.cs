﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BordedControl
{
    public interface IRobot
    {
        public string Model { get; }
    }
}
