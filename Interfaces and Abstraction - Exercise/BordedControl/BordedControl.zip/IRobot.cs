﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BordedControl
{
    public interface IRobot
    {
        public string Name { get; }
        public string Id { get; }
    }
}
