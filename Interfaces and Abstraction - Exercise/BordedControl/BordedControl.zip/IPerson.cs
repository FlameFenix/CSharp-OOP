﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BordedControl
{
    public interface IPerson
    {
        public string Name { get; }
        public int Age { get; }
        public string Id { get; }
    }
}
